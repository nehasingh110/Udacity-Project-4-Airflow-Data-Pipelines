from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.contrib.hooks.aws_hook import AwsHook

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'
    
    trunc_sql = """
        truncate {}
    """
    
    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 aws_credentials_id="",
                 create_sql="",
                 insert_sql="",
                 mode="",
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id=redshift_conn_id
        self.aws_credentials_id=aws_credentials_id
        self.create_sql=create_sql
        self.insert_sql=insert_sql
        self.mode=mode

    def execute(self, context):
        self.log.info('LoadDimensionOperator not implemented yet')
        
        self.log.info('Estabilishing connection now')
        aws_hook = AwsHook(self.aws_credentials_id)
        credentials = aws_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        self.log.info('Connection successful')
        
        formatted_sql = LoadDimensionOperator.trunc_sql.format(self.table)  
        
        redshift.run(self.create_sql)
        if self.mode == "delete-load":
            redshift.run(formatted_sql) 
            
        redshift.run(self.insert_sql)
        
        self.log.info('LoadDimensionOperator implemented successfully')
        