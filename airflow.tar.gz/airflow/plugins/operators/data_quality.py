from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.contrib.hooks.aws_hook import AwsHook

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 aws_credentials_id="",
                 table="",
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id=redshift_conn_id
        self.aws_credentials_id=aws_credentials_id
        self.table=table

    def execute(self, context):
        self.log.info('DataQualityOperator not implemented yet')
        
        self.log.info('Estabilishing connection now')
        aws_hook = AwsHook(self.aws_credentials_id)
        credentials = aws_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        self.log.info('Connection successful')
        
        table_name = self.table
        records = redshift.get_records(f"SELECT COUNT(*) FROM {table_name}")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. {table_name} returned no results")
        
        num_records = records[0][0]
        if records is None or num_records < 1:
            raise ValueError(f"No records present in destination table {table_name}")

        self.log.info(f"Data quality on table {table_name} check passed with {records[0][0]} records")
        
        self.log.info('DataQualityOperator implemented successfully')