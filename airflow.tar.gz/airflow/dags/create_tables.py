CREATE_ARTISTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.artists (
	artistid varchar(256) NOT NULL,
	name varchar(256),
	location varchar(256),
	lattitude numeric(18,0),
	longitude numeric(18,0)
);
"""

CREATE_SONGPLAYS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.songplays (
	playid bigint identity(1, 1),
	start_time BIGINT NOT NULL,
	userid int4 NOT NULL,
	"level" varchar(256),
	songid varchar(256),
	artistid varchar(256),
	sessionid int4,
	location varchar(256),
	user_agent varchar(256),
	CONSTRAINT songplays_pkey PRIMARY KEY (playid)
);
"""

CREATE_SONGS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.songs (
	songid varchar(256) NOT NULL,
	title varchar(256),
	artistid varchar(256),
	"year" int4,
	duration numeric(18,0),
	CONSTRAINT songs_pkey PRIMARY KEY (songid)
);
"""

CREATE_STAGING_EVENTS_SQL = """
CREATE TABLE IF NOT EXISTS public.staging_events (
	artist varchar(256),
	auth varchar(256),
	firstname varchar(256),
	gender varchar(256),
	iteminsession int4,
	lastname varchar(256),
	length numeric(18,0),
	"level" varchar(256),
	location varchar(256),
	"method" varchar(256),
	page varchar(256),
	registration numeric(18,0),
	sessionid int4,
	song varchar(256),
	status int4,
	ts int8,
	useragent varchar(256),
	userid int4
);
"""

CREATE_STAGING_SONGS_SQL = """
CREATE TABLE IF NOT EXISTS public.staging_songs (
	num_songs int4,
	artist_id varchar(256),
	artist_name varchar(256),
	artist_latitude numeric(18,0),
	artist_longitude numeric(18,0),
	artist_location varchar(256),
	song_id varchar(256),
	title varchar(256),
	duration numeric(18,0),
	"year" int4
);
"""

CREATE_USERS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.users (
	userid int4 NOT NULL,
	first_name varchar(256),
	last_name varchar(256),
	gender varchar(256),
	"level" varchar(256),
	CONSTRAINT users_pkey PRIMARY KEY (userid)
);
"""

songplay_table_insert = """INSERT INTO songplays (start_time, userid, level, songid, artistid, 
                        sessionid, location, user_agent) 
                        select e.ts as start_time, e.userId as userid, e.level, s.song_id as songid, 
                        s.artist_id as artistid,e.sessionid as sessionid, e.location, e.useragent 
                        as user_agent from staging_events e left join staging_songs s 
                        on e.song = s.title and e.artist = s.artist_name;"""

user_table_insert = """INSERT INTO users ( userid, first_name, last_name, gender, level) 
                        select distinct userid, firstname as first_name, 
                        lastname as last_name, gender, max(level) as level from staging_events where 
                        userid is not null group by 1,2,3,4;"""

song_table_insert = """INSERT INTO songs (songid, title, artistid, year, duration) 
                        select distinct song_id as songid, title, artist_id as artistid, year, duration from 
                        staging_songs where song_id is not null; """

artist_table_insert = """INSERT INTO artists (artistid, name, location, lattitude, longitude) 
                        select distinct artist_id as artistid, artist_name as name, artist_location as location,
                        artist_latitude as lattitude, artist_longitude as longitude from staging_songs 
                        where artist_id is not null;"""




