from datetime import datetime, timedelta
import logging
import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators import (StageToRedshiftOperator, LoadDimensionOperator, 
                               LoadFactOperator, DataQualityOperator)
from helpers import SqlQueries
from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.postgres_operator import PostgresOperator
import create_tables

# AWS_KEY = os.environ.get('AWS_KEY')
# AWS_SECRET = os.environ.get('AWS_SECRET')

default_args = {
    'owner': 'udacity',
    'start_date': datetime(2019, 8, 4)
}

dag = DAG('udac_ns_dag',
          default_args=default_args,
          description='Load and transform data in Redshift with Airflow',
          schedule_interval='0 * * * *'
        )

start_operator = DummyOperator(task_id='Begin_execution',  dag=dag)

create_events_table = PostgresOperator(
    task_id = "create_events_table",
    dag=dag,
    postgres_conn_id = "redshift",
    sql=create_tables.CREATE_STAGING_EVENTS_SQL
)

stage_events_to_redshift = StageToRedshiftOperator(
    task_id='Stage_events',
    dag=dag,
    table="staging_events",
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    s3_bucket="log_data/2018/11/2018-11-01-events.json",
    s3_key="s3://udacity-dend/log_json_path.json"
)

create_songs_table = PostgresOperator(
    task_id = "create_songs_tables",
    dag=dag,
    postgres_conn_id = "redshift",
    sql=create_tables.CREATE_STAGING_SONGS_SQL
)

stage_songs_to_redshift = StageToRedshiftOperator(
    task_id='Stage_songs',
    dag=dag,
    table="staging_songs",
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    s3_bucket="song_data",
    s3_key="auto"
)

load_songplays_table = LoadFactOperator(
    task_id='Load_songplays_fact_table',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    create_sql=create_tables.CREATE_SONGPLAYS_TABLE_SQL,
    insert_sql=create_tables.songplay_table_insert
)

load_user_dimension_table = LoadDimensionOperator(
    task_id='Load_user_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    create_sql=create_tables.CREATE_USERS_TABLE_SQL,
    insert_sql=create_tables.user_table_insert
)

load_song_dimension_table = LoadDimensionOperator(
    task_id='Load_song_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    create_sql=create_tables.CREATE_SONGS_TABLE_SQL,
    insert_sql=create_tables.song_table_insert
)

load_artist_dimension_table = LoadDimensionOperator(
    task_id='Load_artist_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    create_sql=create_tables.CREATE_ARTISTS_TABLE_SQL,
    insert_sql=create_tables.artist_table_insert
)

songplay_run_quality_checks = DataQualityOperator(
    task_id='songplay_run_quality_checks',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table = "songplays"
)

artist_run_quality_checks = DataQualityOperator(
    task_id='artist_run_quality_checks',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table = "artists",
    mode = "delete-load"
)

song_run_quality_checks = DataQualityOperator(
    task_id='song_run_quality_checks',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table = "songs",
    mode = "delete-load"
)

user_run_quality_checks = DataQualityOperator(
    task_id='user_run_quality_checks',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table = "users",
    mode = "delete-load"
)

end_operator = DummyOperator(task_id='Stop_execution',  dag=dag)

create_events_table >> stage_events_to_redshift
create_songs_table >> stage_songs_to_redshift
stage_events_to_redshift>>load_songplays_table
stage_songs_to_redshift>>load_songplays_table
load_songplays_table >> load_user_dimension_table
load_songplays_table >> load_song_dimension_table
load_songplays_table >> load_artist_dimension_table
load_user_dimension_table >> songplay_run_quality_checks
load_song_dimension_table >> songplay_run_quality_checks
load_artist_dimension_table >> songplay_run_quality_checks
songplay_run_quality_checks >> artist_run_quality_checks
songplay_run_quality_checks >> song_run_quality_checks
songplay_run_quality_checks >> user_run_quality_checks
user_run_quality_checks >> end_operator